<?php
class BoosterMasterSDS extends Booster {
	
	public function __construct(){
		parent::__construct("nead.univ-angers.fr", "/celcat/istia/g2485");
	}
}
